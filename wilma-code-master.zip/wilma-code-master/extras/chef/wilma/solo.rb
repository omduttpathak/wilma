cookbook_path '/var/chef/cookbooks'
file_cache_path '/var/chef/cookbooks/.cache'
log_level :debug
log_location STDOUT